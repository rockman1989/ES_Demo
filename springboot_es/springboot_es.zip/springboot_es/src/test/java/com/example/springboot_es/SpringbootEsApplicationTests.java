package com.example.springboot_es;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootEsApplicationTests {

	@Test
	void contextLoads() {
	}

}
